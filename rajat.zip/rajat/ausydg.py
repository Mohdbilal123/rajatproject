a=open ('rajat.txt','r')
s=a.read(15)
print(s)
a.close()
