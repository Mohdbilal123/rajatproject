from data.channel import Channel
from tkinter import *
import threading
import time
    
class Main:
	def __init__(self,root):
		self.root=root
		self.channel=Channel(
			'https://onlineattendence.art.blog',
			'stellerxotpsystem',
			'stellerx.incorrect')
		self.HomeScreen()
		
		
	def HomeScreen(self):
		f=Frame(self.root,bg='white',width=720,height=1600).place(x=0,y=0)
		ftop=Frame(f,bg='forest green',width=720,height=130).place(x=0,y=0)
		Label(f,text='Chat Portal',bg='forest green',fg='white',font='verdana 13 bold').place(x=50,y=20)
		
		Label(f,text='CHANNEL NAME',bg='white',font='verdana 6').place(x=50,y=190)
		self.CHANNEL_NAME=StringVar()
		self.USER_NAME=StringVar()
		Entry(f,textvariable=self.CHANNEL_NAME).place(x=50,y=230,width=600,height=80)
		Label(f,text='USER NAME',bg='white',font='verdana 6').place(x=50,y=340)
		Entry(f,textvariable=self.USER_NAME).place(x=50,y=385,width=600,height=80)
		
		Button(f,text='create Channel',bg='dodger blue',fg='white',padx=125).place(x=100,y=900)
		Button(f,text=' join ',bg='dodger blue',padx=200,fg='white',command=self.startCHAT).place(x=100,y=1000-20)
		Button(f,text=' Exit ',bg='white',fg='red',padx=200).place(x=100,y=1000+220-150)
	
	def startCHAT(self):
		self.channelID=self.CHANNEL_NAME.get()
		user=self.USER_NAME.get()
		threading.Thread(target=self.recieve).start()
		f2=Frame(self.root,bg='white',width=720,height=1600).place(x=0,y=0)
		Frame(f2,bg='forest green',width=720,height=130).place(x=0,y=0)
		Label(f2,text='you r on - ' +str(self.channelID)+' channel !',font='verdana 7',bg='forest green').place(x=20,y=20)
		self.chatbox=Listbox(f2)
		self.chatbox.place(x=10,y=135,width=700,height=500)
		self.chat=StringVar()
		Entry(f2,textvariable=self.chat).place(x=10,y=637,width=620,height=80)
		Button(f2,text='√',command=self.send).place(x=639,y=637,width=70,height=80)
	
	def send(self):
		self.chatTrue=self.chat.get() #data to send
		self.chat.set('')
		self.chatbox.insert(END,self.chatTrue)
		self.chatbox.see(END)
		threading.Thread(target=self.sendTrue).start()
		
	def sendTrue(self):
		self.channel.Send(self.channelID,self.chatTrue)
		
	def recieve(self):
		while True:
			msg=self.channel.Recieve(self.channelID)
			if msg=='$':
				continue
			else:
				self.chatbox.insert(END,msg)
				self.chatbox.see(END)
			time.sleep(0.10)
	
	def createCHANNEL(self):
		channel=self.CHANNEL_NAME.get()
		user=self.USER_NAME.get()
		self.channel.NewChannel(channel)
		f2=Frame(self.root,bg='white',width=720,height=1600).place(x=0,y=0)
		Frame(f2,bg='forest green',width=720,height=130).place(x=0,y=0)
		Label(f2,text='you r on - ' +str(channel)+' channel !',font='verdana 7',bg='forest green').place(x=20,y=20)
		
		
if __name__=='__main__':
	Display=Tk()
	Main(Display)
	Display.mainloop()


