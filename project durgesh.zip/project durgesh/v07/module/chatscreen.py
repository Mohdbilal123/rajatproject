from tkinter import *
from cloudhost import Cloudhost



def chatscreen(root):
    global msg,a
    root.config(bg='black')
    root.geometry('700x500')
    a=Listbox()
    a.place(x=50,y=100)
    msg=StringVar()
    Entry(root,textvariable=msg).place(x=100,y=300)

    root.bind('<Return>',lambda e:send())
    
def send():
    global msg,a
    a.insert(END,str(msg.get()))
    a.see(END)
    msg.set('')
    
if __name__=='__main__':
    root=Tk()
    chatscreen(root)
    root.mainloop()
