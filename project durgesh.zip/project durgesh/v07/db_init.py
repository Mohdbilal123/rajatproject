from KEEpydb import KEEpydb
#KEEpydb.core().create_database('db','stellerx','12345678')
q=KEEpydb.query('db','stellerx','12345678')
q.update('a1','password')
q.update('b1','8571')