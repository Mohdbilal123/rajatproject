from tkinter import *
class Functions:
	def __init__(self,root):
		self.root=root
		self.root.config(bg='white')
		
	def check(self):
		if str(self.key.get())=='8429416181':
			self.root.config(bg='green')
		else:
			self.root.config(bg='red')
			self.encrypt_key.set('')
			self.key.set('')
			
	def one(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'1')
	def two(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'2')
	def three(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'3')
	def four(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'4')
	def five(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'5')
	def six(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'6')
	def seven(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'7')
	def eight(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'8')
	def nine(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'9')
	def zero(self):
		self.encrypt_key.set(str(self.encrypt_key.get())+'*')
		self.key.set(str(self.key.get())+'0')
	def backspace(self):
		self.encrypt_key.set(str(self.encrypt_key.get())[0:len(str(self.encrypt_key.get()))-1])
		self.key.set(str(self.key.get())[0:len(str(self.key.get()))-1])
	def clear(self):
		self.key.set('')
		self.encrypt_key.set('')
		
	def LockScreen(self):
		self.key=StringVar()
		self.encrypt_key=StringVar()
		Entry(self.root,textvariable=self.encrypt_key).place(x=20,y=20)
		Button(self.root,text='1',command=self.one).place(x=50,y=30+40)
		Button(self.root,text='2',command=self.two).place(x=160,y=30+40)
		Button(self.root,text='3',command=self.three).place(x=270,y=30+40)
		Button(self.root,text='4',command=self.four).place(x=50,y=100+40)
		Button(self.root,text='5',command=self.five).place(x=160,y=100+40)
		Button(self.root,text='6',command=self.six).place(x=270,y=100+40)
		Button(self.root,text='7',command=self.seven).place(x=50,y=170+40)
		Button(self.root,text='8',command=self.eight).place(x=160,y=170+40)
		Button(self.root,text='9',command=self.nine).place(x=270,y=170+40)
		Button(self.root,text='0',command=self.zero).place(x=160,y=240+40)
		Button(self.root,text='c',command=self.clear).place(x=50,y=240+40)
		Button(self.root,text='#',command=self.backspace ).place(x=270,y=240+40)
		
		Button(self.root,text='ENTER',padx=135,bg='dodger blue',command=self.check).place(x=20,y=360)
		
if __name__=='__main__':
	root=Tk()
	Functions(root).LockScreen()
	root.mainloop()