import socket
import threading

PORT=5050
HEADER=64
FORMAT='utf-8'
DISSCONNECT_MESSAGE='OFFLINE'

#SERVER='192.168.43.187' #REDMI
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)

clients_name=[]
clients_data=[]
def handle_client(conn,addr):
    username=conn.recv(1024*10).decode(FORMAT)
    clients_name.append(username)
    clients_data.append(addr)
    print(f'[NEW CONNECTION] {username} connected ')
    connected=True
    while connected:
        conn.send('connected'.encode(FORMAT))
        msg_length=conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length=int(msg_length)
            msg=conn.recv(msg_length).decode(FORMAT)
            if msg==DISSCONNECT_MESSAGE:
                connected=False
            print(f'[{addr}] {msg}')
            #conn.send(input('msg:').encode(FORMAT))
    conn.close()

def start():
    server.listen()
    print(f'[LISTINING] SERVER ON {SERVER}')
    while True:
        conn,addr=server.accept()
        thread=threading.Thread(target=handle_client,args=(conn,addr))
        thread.start()
        print(f'[ACTIVE CONNECTIONS] {threading.activeCount()-1}')
start()