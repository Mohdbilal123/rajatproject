
	def autologin(self):
		with open('database/settings/accounts.txt','r') as fi:
			l=fi.readlines()
		
		USERNAME,PASSWORD=l[0][0],l[0][1]
		
		
		with open('database/settings/server_info.txt','r') as fi:
				data=fi.readlines()
				data=data[0]
				data=data.split(',')
				try:
					client.connect_client(USERNAME,data[0],int(data[1]))
					self.chat_home_screen()
				except:
					msgbox.showwarning('ERROR','SERVER IS NOT ONLINE ! \n')

	def chat(self):
		self.frame=Frame(self.root,height=self.height,width=self.width,bg='black').place(x=0,y=0)
		Label(self.frame,text='Chat Room',font='verdana 12 bold',fg='white',bg='black').place(x=20,y=20)
		global screen
		screen=Listbox(self.frame,width=36)
		screen.insert(END,client.recieve())
		screen.place(x=20,y=100)
		
		global text
		text=StringVar()
		Entry(self.frame,textvariable=text,width=27).place(x=20,y=510)
		
		
		b=Button(self.frame, text='send',pady=4,bg='dodger blue',command=self.send_chat)
		#b.image=self.sendpng
		b.place(x=560,y=507)
		
	def send_chat(self): #func for send button in chatroom
		global text,screen
		screen.insert(END,text.get())
		client.send(text.get())
		if text.get() =='EXIT':
			client.close_connection()
			self.chat_home_screen
		
		text.set('')

		
	def button_function_3dot(self):
		self.layer=Frame(self.root,height=self.height,width=self.width).place(x=0,y=0)
		self.username=USERNAME.get()
		
		Button(self.layer,text='back',bg='SeaGreen2',command=self.chat_home_screen).place(x=550,y=20)
		Label(self.layer,text=str(self.username)).place(x=20,y=20)

def login_as_user(self):
		global USERNAME
		global PASSWORD
		
		
		with open('database/settings/accounts.txt','r') as fi:
			l=fi.readlines()
		
		for i in range(len(l)):
			l=l[i]
			
			"""
			l=l.split(',')
			if l[i]+l[i+1] == str(USERNAME.get())+str(PASSWORD.get()):
				try:
					with open('database/settings/server_info.txt','r') as fi:
						data=fi.readlines()
						data=data[0]
						data=data.split(',')
	
						#
						client.connect_client(USERNAME.get(),data[0],int(data[1]))
						self.chat_home_screen()
			
				except Exception as e:
					msgbox.showwarning('ERROR','SERVER IS NOT ONLINE ! or \n'+str(e))		
				
				finally:
					msgbox.showinfo('alert','Incorrect username or password')
			else:
				pass #msgbox.showinfo('alert','Incorrect username or password')
			"""
			
	def login__(self):
		with open('database/settings/server_logs.txt','r') as f:
			data=f.readlines()
			if data[0] == 'auto_login=TRUE':
				self.autologin()
			else:
				self.home()