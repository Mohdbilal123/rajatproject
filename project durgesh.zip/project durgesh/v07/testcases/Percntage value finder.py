

"""
total width = 720
1 % of the screen = 7.2

i will allow  == 0 to 100 %
"""


def cnvt_to_percentage(width):
	return width*1/100 #it is the width's 1%
	
def pw(percentage_value,Width_or_Height):
	return cnvt_to_percentage(Width_or_Height)*100/Width_or_Height
	# actual value what have to be done to respecrive functionality

def ph():
	return cnvt_to_percentage(Width_or_Height)*100/Width_or_Height
	# actual value what have to be done to respecrive functionality


#how much %
def hmp(x,wid_or_hei):
	return x/wid_or_hei*100
print(hmp(440,720))

	
	