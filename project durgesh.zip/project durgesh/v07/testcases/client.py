import socket
def connect_client(username,ip,port):
	global PORT,HEADER,FORMAT,DISSCONNECT_MESSAGE,SERVER,ADDR,client
	PORT=port
	HEADER=64
	FORMAT='utf-8'
	DISSCONNECT_MESSAGE='OFFLINE'

	SERVER=ip
	ADDR=(SERVER,PORT)
	
	client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	client.connect(ADDR)
	client.send(username.encode(FORMAT))
	return True

def send(msg):
	   global PORT,HEADER,FORMAT,DISSCONNECT_MESSAGE,SERVER,ADDR,client
	   FORMAT='utf-8'
	   HEADER=64
	   message=msg.encode(FORMAT)
	   msg_length=len(message)
	   send_length=str(msg_length).encode(FORMAT)
	   send_length+=b' '*(HEADER-len(send_length))
	   client.send(send_length)
	   client.send(message)
	   print(client.recv(2048).decode(FORMAT))

def recieve():
	global PORT,HEADER,FORMAT,DISSCONNECT_MESSAGE,SERVER,ADDR,client
	return client.recv(2048).decode('utf-8')

def close_connection():
	global client
	client.close()

while True:
    connect_client('Durgesh','127.0.0.1',5050)
    send('hello world')
	