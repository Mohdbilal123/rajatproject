import readtool
from tkinter import *
from PIL import ImageTk, Image
import time
from tkinter import messagebox as msgbox
import client

#settingfile
SETTINGS=readtool.read('database/settings/settings.txt',':')


#new idea functionality
#
#
#

class allDATA:
	def __init__(self,root):
		self.root=root
		self.width=SETTINGS['width']
		self.height=SETTINGS['height']
		self.root.geometry(f'{self.width}x{self.height}')
		

#introduction an frame for app introduction		
class INTRO(allDATA):
	def __init__(self):
		super(INTRO,self).__init__(root)
		frameINTRO=Frame(self.root,width=self.width,height=self.height,bg=SETTINGS['INTRO BG']).place(x=0,y=0)
		
		#instance for image
		photo=ImageTk.PhotoImage(Image.open(SETTINGS['INTRO BG ICON']).resize((400,400), Image.ANTIALIAS))
		label=Label(frameINTRO, image=photo,bg='white')
		label.image=photo
		label.place(x=160,y=410)

#login 
class web(allDATA): # for all web services
	def __init__(self):
		super(web,self).__init__(root)
		
		#loading && 
		self.user_icon=ImageTk.PhotoImage(Image.open(SETTINGS['USER ICON']).resize((400,400), Image.ANTIALIAS))
		self.photothreedot=ImageTk.PhotoImage(Image.open(SETTINGS['BUTTON RIGHT 3 DOT']).resize((60,60), Image.ANTIALIAS))
		self.photofornewchat=ImageTk.PhotoImage(Image.open(SETTINGS['MORE BUTTON']).resize((60,60),Image.ANTIALIAS))
		self.sendpng=ImageTk.PhotoImage(Image.open(SETTINGS['SEND BUTTON']).resize((100,48),Image.ANTIALIAS))
	
		#what next after this
		self.home()


	
	def home(self): # Function for O N L I N E SERVICES
		self.frameLOGIN=Frame(self.root,height=self.height,width=self.width,bg='white').place(x=0,y=0)
		
		self.header=Label(self.frameLOGIN,text='Welcome To',bg='white',font='verdana 14 ')
		self.header1=Label(self.frameLOGIN,text=SETTINGS['TITLE'],bg='white',font='verdana 16 bold')
		self.header.place(x=20,y=20)
		self.header1.place(x=280,y=20)
		image=Image.open(SETTINGS['INTRO BG ICON'])
		photo=ImageTk.PhotoImage(image.resize((400,400), Image.ANTIALIAS))
		label=Label(self.frameLOGIN, image=photo,bg='white')
		label.image=photo
		label.place(x=160,y=300)
		
		#self.newframe=Frame(self.frameLOGIN,width=int(self.width)-200,height=int(self.height)-600,bg='white')
		#self.newframe.place(x=100,y=200)	
			
		#buttons
		self.signupButton=Button(self.frameLOGIN,text='Create Connection',bg='white',fg='dodger blue',padx=187,command=self.CreateAccount).place(x=38,y=1065)
		self.loginButton=Button(self.frameLOGIN,text='Login',bg='dodger blue',fg='white',padx=280,command=self.login_connection).place(x=38,y=1140)
		
	def login_connection(self):
		self.frame_login_connection=Frame(self.root,width=self.width,height=self.height,bg='white').place(x=0,y=0)
		Label(self.frame_login_connection,text='User Login',font='verdana 13 bold',bg='white').place(x=20,y=20)
		label=Label(self.frame_login_connection, image=self.user_icon,bg='white')
		label.image=self.user_icon
		label.place(x=160,y=150)
		
		global USERNAME,PASSWORD
		USERNAME=StringVar()
		PASSWORD=StringVar()
		
		Label(self.frame_login_connection,text='UserName',bg='white').place(x=70,y=600)
		Label(self.frame_login_connection,text='password',bg='white').place(x=70,y=650)
			
		Entry(self.frame_login_connection,textvariable=USERNAME).place(x=250,y=600)
		Entry(self.frame_login_connection,textvariable=PASSWORD).place(x=250,y=650)
		
		Button(self.frame_login_connection,text='LOGIN',padx=150,bg='SeaGreen2',command=self.login_as_user).place(x=160,y=850)
		Button(self.frame_login_connection,text='back',padx=163,bg='white',command=self.home).place(x=160,y=930)
		
		
	
	
	def CreateAccount(self):
		self.frame_CreateAccount=Frame(self.frameLOGIN,width=self.width,height=self.height,bg='white').place(x=0,y=0)
		Label(self.frame_CreateAccount,text='Establish Connection',font='verdana 13 bold',bg='white').place(x=20,y=20)
		
		label=Label(self.frame_CreateAccount, image=self.user_icon,bg='white')
		label.image=self.user_icon
		label.place(x=160,y=150)
		
		#terms and condition
		self.checkbuttonvalue=IntVar()
		self.checkbutton=Checkbutton(self.frame_CreateAccount,text='agree to our terms and condions',bg='white',relief=FLAT,variable=self.checkbuttonvalue,offvalue=0,onvalue=1)
		self.checkbutton.invoke()
		self.checkbutton.place(x=50,y=int(SETTINGS['height'])-100)

		
		global UNAME,PASS
		self.username=StringVar()
		self.password=StringVar()
		UNAME,PASS=self.username,self.password
		Label(self.frame_CreateAccount,text='Username',bg='white',justify=CENTER).place(x=70,y=600)
		Label(self.frame_CreateAccount,text='password',bg='white',justify=CENTER).place(x=70,y=650)
		Entry(self.frame_CreateAccount,textvariable=self.username,justify=CENTER).place(x=250,y=600)
		Entry(self.frame_CreateAccount,textvariable=self.password).place(x=250,y=650)
		
		Button(self.frame_CreateAccount,text=' back ',bg='white',command=self.home).place(x=100,y=800)
		Button(self.frame_CreateAccount,text='proceed',bg='SeaGreen2',command=self.proceed).place(x=350,y=800)
		
	def proceed(self):#proceed button under create account
		self.frame_proceed=Frame(self.root,width=self.width,height=self.height,bg=SETTINGS['FRAME BG']).place(x=0,y=0)
		Label(self.frame_proceed,text='Complete Profile',font='verdana 12 bold',bg='white').place(x=20,y=20)
		
		global First_name,Last_name,Age,Gender,phone_no
		First_name=StringVar()
		Last_name=StringVar()
		Age=StringVar() #} age
		Gender=StringVar()
		phone_no=StringVar()
		
		Label(self.frame_proceed,text='First Name',bg='white').place(x=50,y=150)
		Entry(self.frame_proceed,textvariable=First_name).place(x=250,y=150)	
		Label(self.frame_proceed,text='Last Name',bg='white').place(x=50,y=200)
		Entry(self.frame_proceed,textvariable=Last_name).place(x=250,y=200)	
		Label(self.frame_proceed,text='Age',bg='white').place(x=50,y=300-50)
		Entry(self.frame_proceed,textvariable=Age,justify=CENTER).place(x=250,y=300-50)		
		Label(self.frame_proceed,text='Gender',bg='white').place(x=50,y=400-100)
		Entry(self.frame_proceed,textvariable=Gender).place(x=250,y=400-100)	
		Label(self.frame_proceed,text='Phone No',bg='white').place(x=50,y=500-150)
		Entry(self.frame_proceed,textvariable=phone_no).place(x=250,y=500-150)		
		Button(self.frame_proceed,text='Tap to Submit',padx=200,bg='SeaGreen3',command=self.save_new_account_info).place(x=50,y=500)
		Button(self.frame_proceed,text='back',padx=268,bg='SlateBlue1',command=self.CreateAccount).place(x=50,y=550+20)
		
	def save_new_account_info(self):#tap to begin button under proceed button under create account
		global UNAME,PASSFirst_name,Last_name,Age,Gender,phone_no
		with open('database/settings/accounts.txt','a') as fi:
			fn=First_name.get()
			ln=Last_name.get()
			age=Age.get()
			gender=Gender.get()
			phone=phone_no.get()
			username=UNAME.get()
			password=PASS.get()
			fi.write(f'{username},{password},{fn},{ln},{age},{gender},{phone}\n')			

	def login_as_user(self):
		pass
		
	def chat_home_screen(self):
		#mainFRAME
		self.frameMAIN=Frame(
			self.root,
			height=self.height,
			width=self.width,bg=SETTINGS['HOME BG']).place(x=0,y=0)
		
		#TITLE
		self.TitleBar=Label(self.frameMAIN,text='StellarX'+' '*50,font='blackcasper 12',bg='black',fg='white',relief=SUNKEN,padx=50,pady=25)
		self.TitleBar.place(x=0,y=-1)
		
		#MORE BUTTON 3DOT
		self.button=Button(self.frameMAIN, image=self.photothreedot,bg='black',padx=5,command=self.button_function_3dot)
		self.button.image=self.photothreedot
		self.button.place(x=620,y=25)
		
		#NEWCHAT BUTTON
		self.buttonplusCHAT=Button(self.frameMAIN,image=self.photofornewchat,bg='black')
		self.buttonplusCHAT.image=self.photofornewchat
		self.buttonplusCHAT.place(x=550,y=25)
		
		Label(self.frameMAIN,text='Start a Chat ...',font='verdana 12',bg=SETTINGS['HOME BG'],fg='green').place(x=210,y=900)
		#m=connect_client(IP,PORT).recieve()
		Button(self.frameMAIN,text='Enter in Chat room',padx=100,bg='SeaGreen2',command=self.chat).place(x=20,y=150)



class OnlineOffline(allDATA): # for all web services
	def __init__(self):
		super(OnlineOffline,self).__init__(root)
		self.frameOnlineOffline=Frame(self.root,height=self.height,width=self.width,bg='white').place(x=0,y=0)
		Button(self.frameOnlineOffline,text='Room Mode',bg='green',fg='white').place(x=100,y=400)
		Button(self.frameOnlineOffline,text='Start Application',bg='green',fg='white',command=web).place(x=100,y=500)
		
if __name__=='__main__': # here i used this statement for show that( ager ye programm directley isi programm se run ho rhau hai to hinchale warna naa chale (justlike ager koi mere is module ko import kre to ye jo if ke indent me likha hai wo na run ho) )
	root=Tk()
	allDATA(root)
	INTRO()
	root.update_idletasks()
	time.sleep(1.5)
	web()
	#OnlineOffline()
	root.mainloop()