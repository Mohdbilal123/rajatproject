import readtool
from tkinter import *
from PIL import ImageTk, Image
import time
from tkinter import messagebox as msgbox
from funcforgui import updateUserInfo,getUserInfo,getUserInfoForNewChat
import os,funcforgui
from multiprocessing import Process
from KEEpydb import KEEpydb
from winaddress import win
from online import client

#settingfile
SETTINGS=readtool.read(win('database/settings/settings.txt'),':')


#new idea functionality
#

class allDATA:
	def __init__(self,root):
		self.q=KEEpydb.query('db','stellerx','12345678')
		self.root=root
		self.width=SETTINGS['width']
		self.height=SETTINGS['height']
		self.root.geometry(f'{self.width}x{self.height}+0+0')
		self.root.maxsize(int(self.width),int(self.height))
		self.root.minsize(int(self.width),int(self.height))
		self.root.title('Steller X')

		#load database CHATS
		terminal=client.Terminal()
		
		
		#loading image
		self.backbutton=ImageTk.PhotoImage(Image.open(SETTINGS['BACK BUTTON']).resize((25,25), Image.ANTIALIAS))
		self.createacc=ImageTk.PhotoImage(Image.open(SETTINGS['CREATE ACC']).resize((int(self.width),int(self.height)), Image.ANTIALIAS))
		self.linknewacc=ImageTk.PhotoImage(Image.open(SETTINGS['LINK NEW ACC']).resize((150,150), Image.ANTIALIAS))
		self.nextButton=ImageTk.PhotoImage(Image.open(SETTINGS['NEXT BUTTON LOGIN']).resize((175,35), Image.ANTIALIAS))
	#	self.threebarspng=ImageTk.PhotoImage(Image.open(SETTINGS['THREE BARS']).resize((90,90), Image.ANTIALIAS))
		self.statusButton=ImageTk.PhotoImage(Image.open(SETTINGS['STATUS BUTTON']).resize((70,70), Image.ANTIALIAS))
		self.homeButton=ImageTk.PhotoImage(Image.open(SETTINGS['HOME BUTTON']).resize((70,70), Image.ANTIALIAS))
		self.PROFILE=ImageTk.PhotoImage(Image.open(SETTINGS['PROFILE']).resize((int(self.width),int(self.height)), Image.ANTIALIAS))
		self.default_avatar=ImageTk.PhotoImage(Image.open(SETTINGS['DEFAULT AVATAR']).resize((100,100), Image.ANTIALIAS))
		self.settings_icon=ImageTk.PhotoImage(Image.open(SETTINGS['SETTINGS ICON']).resize((55,55), Image.ANTIALIAS))
		self.key_icon=ImageTk.PhotoImage(Image.open(SETTINGS['KEY']).resize((45,45), Image.ANTIALIAS))
		self.about_icon=ImageTk.PhotoImage(Image.open(SETTINGS['ABOUT']).resize((55,55), Image.ANTIALIAS))
		self.uidpng=ImageTk.PhotoImage(Image.open(SETTINGS['uid']).resize((55,55), Image.ANTIALIAS))
		self.default_boy=ImageTk.PhotoImage(Image.open(SETTINGS['DEFAULT BOY']).resize((90,90), Image.ANTIALIAS))
		self.refresh_button=ImageTk.PhotoImage(Image.open(SETTINGS['REFRESH BUTTON']).resize((70,70), Image.ANTIALIAS))
		self.icon=PhotoImage(file='database/assets/bglogo.png')
		self.plus=ImageTk.PhotoImage(Image.open(SETTINGS['PLUS']).resize((25,25), Image.ANTIALIAS))
		self.bg=ImageTk.PhotoImage(Image.open(SETTINGS['16img']).resize((458,435), Image.ANTIALIAS))

		self.login_button=ImageTk.PhotoImage(Image.open(SETTINGS['login']).resize((175,35), Image.ANTIALIAS))


                #RAND BGS
		d=['1img','2img','3img','4img',
                   '15img','16img','13img','18img','14img']

		
		
		self.root.iconphoto(False,self.icon)
class INTRO(allDATA):
	def __init__(self):
		super(INTRO,self).__init__(root)
		frameINTRO=Frame(self.root,width=self.width,height=self.height,bg=SETTINGS['INTRO BG']).place(x=0,y=0)
	
		#instance for image
		photo=ImageTk.PhotoImage(Image.open(SETTINGS['INTRO BG ICON']).resize((150,150), Image.ANTIALIAS))
		label=Label(frameINTRO, image=photo,bg='white')
		label.image=photo
		label.place(x=440,y=140)
		Label(frameINTRO,
                                                   text='STELLER-X',
                                                   bg='white',
                                                   fg='black',
                                                   font='verdana 35 bold').place(x=45,y=185)
		Label(frameINTRO,text='All Rights Are Reserved @2021 S T E L L E R  X',bg='white',fg='grey50').place(x=200,y=460)

#login 
class Main(allDATA): # for all web services
	def __init__(self):
		super(Main,self).__init__(root)

		#what next after this
		#setup_autoLogin
		with open(win('database/logs.txt'),'r') as f:
			fi=f.readlines()
		d=fi[0].split(',')
		if d[0]=='True':
			global USERNAME,PASSWORD
			USERNAME=StringVar()
			PASSWORD=StringVar()
			USERNAME.set(d[1])
			PASSWORD.set(d[2])
			try:
				self.Check_login()
			except:
				msgbox.showwarning('Connection Break','please check Your Internet\nconnection')

		else:
			self.Home()


	
	def Home(self): # Function for O N L I N E SERVICES
		self.frameLOGIN=Frame(self.root,height=self.height,width=self.width,bg='white').place(x=0,y=0)

		self.header=Label(self.frameLOGIN,text='Welcome To',bg='white',font='verdana 14 ')
		self.header1=Label(self.frameLOGIN,text=SETTINGS['TITLE'],bg='white',font='verdana 16 bold')
		self.header.place(x=30,y=30)
		self.header1.place(x=125,y=30)
		image=Image.open(SETTINGS['INTRO BG ICON'])
		photo=ImageTk.PhotoImage(image.resize((200,200), Image.ANTIALIAS))
		label=Label(self.frameLOGIN, image=photo,bg='white')
		label.image=photo
		label.place(x=70,y=130)


		loginbgframe=Frame(self.frameLOGIN,width=300,height=350,bg='dodger blue')
		loginbgframe.place(x=360,y=60)
		#login box
		global USERNAME,PASSWORD
		USERNAME=StringVar()
		PASSWORD=StringVar()

		Label(loginbgframe,
                                                      text='Enter Auth ( login ! )',
                                                       bg='dodger blue',
                                                       fg='white',
                                                       font='verdana 15').place(x=20,y=80-20)		
		e0=Entry(self.frameLOGIN,textvariable=USERNAME,fg='grey',font='verdana 11',bg='light yellow')
		e0.place(x=380,y=180-20,width=250,height=40)
		e1=Entry(self.frameLOGIN,textvariable=PASSWORD,fg='grey',font='verdana 11',bg='light yellow')
		e1.place(x=380,y=230-20,width=250,height=40)
		
		USERNAME.set(' Username')
		PASSWORD.set(' Password')

		e0.bind('<Button-1>',lambda e:USERNAME.set(''))
		e1.bind('<Button-1>',lambda e:PASSWORD.set(''))
		
		
		
		#buttons
		self.loginButton=Button(self.frameLOGIN,
                                                    image=self.nextButton,
                                                        bg='dodger blue',
                                                    font='verdana 17',
                                                    command=self.Check_login)
		self.loginButton.image=self.nextButton
		
		self.loginButton.place(x=415,y=300-20)
		self.signupButton=Label(loginbgframe,text='Sign Up',font='verdana 9 ',fg='white',bg='dodger blue')
		self.signupButton.place(x=117,y=270)

		self.signupButton.bind("<Button-1>",MainFunctions().CreateAccount)
		
		#rememberCheckButton=Checkbutton(self.frameLOGIN,text='  Remember password',font='verdana 5',bg='white').place(x=90,y=760)
		forgetPassword=Label(self.frameLOGIN,text='forget password',bg='white',fg='dodger blue').place(x=245,y=790)
		
	def Check_login(self):
		global USERNAME,PASSWORD
		global data
		data = getUserInfo(USERNAME.get(),PASSWORD.get())
		if data != None:
			Application().HomeScreen()
			with open(win('database/logs.txt'),'w') as f:
				fi=f.write(f'True,{USERNAME.get()},{PASSWORD.get()}')
		else:
			msgbox.showwarning('incorrect','your entered password or \nusername is incorrect')
			self.Home()
			
class MainFunctions(allDATA):
	def __init__(self):
		super(MainFunctions,self).__init__(root)
		
	def CreateAccount(self,event):
		newFrame=Frame(self.root,width=self.width,height=self.height,bg='white').place(x=0,y=0)
		createacc=Label(newFrame,image=self.createacc)
		createacc.image=self.createacc
		#createacc.place(x=-1,y=-1)
		
		backbutton=Label(newFrame,image=self.backbutton,bg='white')
		backbutton.image=self.backbutton
		backbutton.place(x=50,y=20)
		backbutton.bind("<Button-1>",lambda event : Main().Home)
		
		Label(newFrame,text='New',font='verdana 18 bold',bg='white').place(x=90,y=80)
		Label(newFrame,text='Account',font='verdana 18 bold',bg='white').place(x=90,y=115)
		
		linknewacc=Label(newFrame,image=self.linknewacc,bg='white')
		linknewacc.image=self.linknewacc
		linknewacc.place(x=99,y=170)
		
		#Label(newFrame,text='Upload a profile picture\n(optional)                         ',bg='white',font='verdana 6').place(x=300,y=450)
		f=Frame(newFrame,width=300,height=350,bg='dodger blue')
		f.place(x=360,y=60)
		global fullName,userName
		fullName=StringVar()
		userName=StringVar()
		fullname=Entry(newFrame,textvariable=fullName,bg='light yellow',width=28)
		username=Entry(newFrame,textvariable=userName,bg='light yellow',width=28)
		fullname.place(x=390,y=130,height=30,width=235)
		username.place(x=390,y=200,height=30,width=235)
		
		Label(newFrame,text='Full Name',font='verdana 11',bg='dodger blue',fg='white').place(x=390,y=100)
		Label(newFrame,text='User Name',font='vrrdana 11',bg='dodger blue',fg='white').place(x=390,y=175)

	
		
		#Label(newFrame,text='Already have an Account ?',font='verdana 10',bg='dodger blue',fg='white').place(x=300,y=300)
		login_official=Label(newFrame,text='Already have an Account ?',font='verdana 9 bold',fg='white',bg='dodger blue')
		login_official.place(x=420,y=250)
		login_official.bind('<Button-1>',lambda event:Main().Home)

		Button(newFrame,text='Next',font='verdana 9',padx=90,pady=10,bg='green3',fg='white',command=self.CreateAccountSTEP2).place(x=395,y=300)
		Label(newFrame,text='Step ( 1/3 )',
                                                                        font='default 14',
                                                                        bg='white',fg='black').place(x=125,y=365)
		nxticon=Label(newFrame,text='NEXT >',
                                                                        font='default 11',
                                                                        bg='white',fg='GREEN')
		nxticon.place(x=600,y=460)
		nxticon.bind('<Button-1>',lambda event:self.CreateAccountSTEP2())
		
	def CreateAccountSTEP2(self):
		newFrame=Frame(self.root,width=self.width,height=self.height,bg='white')
		newFrame.place(x=0,y=0)

		f=Frame(newFrame,width=300,height=350,bg='dodger blue')
		f.place(x=360,y=60)
		
		createacc=Label(newFrame,image=self.createacc)
		createacc.image=self.createacc
		#createacc.place(x=-1,y=-1)
		
		backbutton=Label(newFrame,image=self.backbutton,bg='white')
		backbutton.image=self.backbutton
		backbutton.place(x=50,y=20)
		backbutton.bind("<Button-1>",lambda event : self.CreateAccount((0)))
		
		Label(newFrame,text='User',font='verdana 18 bold',bg='white').place(x=90,y=80)
		Label(newFrame,text='Credentials',font='verdana 18 bold',bg='white').place(x=90,y=115)
		
		linknewacc=Label(newFrame,image=self.linknewacc,bg='white')
		linknewacc.image=self.linknewacc
		linknewacc.place(x=99,y=170)
		
		global age,gender,email_address
		age=StringVar()
		gender=StringVar()
		email_address=StringVar()
		
		
		age_=Entry(newFrame,textvariable=age,bg='light yellow')
		gender_=Entry(newFrame,textvariable=gender,bg='light yellow')
		email_=Entry(newFrame,textvariable=email_address,bg='light yellow')
		age_.place(x=400,y=134,height=30,width=235)
		gender_.place(x=400,y=210,height=30,width=235)
		email_.place(x=400,y=285,height=30,width=235)
		
		Label(newFrame,text='Age',font='verdana 11',bg='dodger blue',fg='white').place(x=400,y=110)
		Label(newFrame,text='Gender',font='verdana 11',bg='dodger blue',fg='white').place(x=400,y=200-14)
		Label(newFrame,text='email Id',font='verdana 11',bg='dodger blue',fg='white').place(x=400,y=280-20)

		"""
		Label(newFrame,text='Already have an Account ?',font='verdana 5',bg='white').place(x=190,y=115)
		login_official=Label(newFrame,text='Login',font='verdana 5 bold',bg='white',fg='dodger blue')
		login_official.place(x=40,y=150)
		login_official.bind('<Button-1>',lambda event:Main().Home)
		"""
		Button(newFrame,text='Next',font='verdana 9',padx=90,pady=10,bg='green3',fg='white',command=self.CreateAccountSTEP3).place(x=405,y=350)
		Label(newFrame,text='Step ( 2/3 )',
                                                                        font='default 14',
                                                                        bg='white',fg='black').place(x=125,y=365)
		nxticon=Label(newFrame,text='NEXT >',
                                                                        font='default 11',
                                                                        bg='white',fg='GREEN')
		nxticon.place(x=600,y=460)
		nxticon.bind('<Button-1>',lambda event:self.CreateAccountSTEP3())
		
	
	def CreateAccountSTEP3(self):
		newFrame=Frame(self.root,width=self.width,height=self.height,bg='white').place(x=0,y=0)
		newFrame=Frame(self.root,width=self.width,height=self.height,bg='white').place(x=0,y=0)
		createacc=Label(newFrame,image=self.createacc)
		createacc.image=self.createacc
		#createacc.place(x=-1,y=-1)
		
		backbutton=Label(newFrame,image=self.backbutton,bg='white')
		backbutton.image=self.backbutton
		backbutton.place(x=50,y=20)
		backbutton.bind("<Button-1>",lambda event : self.CreateAccountSTEP2())
		
		Label(newFrame,text='User',font='verdana 18 bold',bg='white').place(x=90,y=80)
		Label(newFrame,text='Password',font='verdana 18 bold',bg='white').place(x=90,y=115)
		
		linknewacc=Label(newFrame,image=self.linknewacc,bg='white')
		linknewacc.image=self.linknewacc
		linknewacc.place(x=99,y=170)
		
		Label(newFrame,text='Step ( 3/3 )',
                                                                        font='default 14',
                                                                        bg='white',fg='black').place(x=125,y=365)
		
		f=Frame(newFrame,width=300,height=350,bg='dodger blue')
		f.place(x=360,y=60)
		
		
		
		global password,password2
		password=StringVar()
		password2=StringVar()
		
		password1=Entry(newFrame,textvariable=password,bg='light yellow',width=28)
		password2=Entry(newFrame,textvariable=password2,bg='light yellow',width=28)
		password1.place(x=390,y=130,height=30,width=235)
		password2.place(x=390,y=200,height=30,width=235)
		
		Label(newFrame,text='Create password',font='verdana 11',bg='dodger blue',fg='white').place(x=390,y=100)
		Label(newFrame,text='Confirm password',font='verdana 11',bg='dodger blue',fg='white').place(x=390,y=175)
		#Label(newFrame,text='Authentication system by Steller X',font='verdana 5',bg='white').place(x=190,y=1150)
		Button(newFrame,text='Getting Started with New Account',bg='green3',fg='white',padx=20,pady=10,command=self.check).place(x=395,y=300)
		nxticon=Label(newFrame,text='NEXT >',
                                                                        font='default 11',
                                                                        bg='white',fg='GREEN')
		nxticon.place(x=600,y=460)
		nxticon.bind('<Button-1>',lambda event:self.check())
	def check(self):
		global password,password2,userName,fullName,age,gender,email_address
		if password.get()==password2.get():
			if updateUserInfo([userName.get(),password.get(),fullName.get(),age.get(),gender.get(),email_address.get()]) == True:
				Main().Home()
				global USERNAME,PASSSWORD
				USERNAME.set(userName.get())
				PASSWORD.set(password2.get())
				msgbox.showinfo('notification',f'account created sucessfully\nusername:{userName.get()}\npassword:{password.get()}')
		else:
			msgbox.showwarning('alert','password do not match on second time')

	def login_on_new_account(self):
		global userName,password,fullName,age,gender,email_address
	def Login(self):
		pass
		
		
class ChatUi(allDATA):
	def __init__(self):
		super(ChatUi,self).__init__(root)
	
	def ChatScreen(self,name):
		with open(win('database/settings/chatlayout'),'r') as f:
			da=f.readlines()
			da=da[0]
		global chatvar,list_box,indexing,yplace,heightofbox
		
		yplace=int(self.height)-120
		heightofbox=23
		
		if da=='chatlayout=desktop':
			self.chatscreenDESKTOP(name)
		
		else:
			self.chatscreenMOBILE(name)
	
	def chatscreenMOBILE(self,name):
		
		if True:
			c=Frame(self.root,height=self.height,width=self.width,bg='white')
			c.place(x=0,y=0)
			global list_box,indexing
			indexing=0
			list_box=Listbox(c,fg='cyan',bg='#222',font='verdana 11')
			list_box.place(x=250,y=45,width=420,height=410,)
			
			Label(c,text=' ',bg='lawn green',relief=RAISED).place(x=250,y=-1,width=420,height=90)
			Label(c,text=' ＣＯＮＶＥＲＳＡＴＩＯＮ',bg='lawn green',fg='black',font='verdana 15').place(x=330,y=30)
			Label(c,text=' ≡',bg='lawn green',fg='white',font='verdana 15').place(x=620,y=50)
			
			l=Label(c,image=self.backbutton,bg='white',font='verdana 15 bold')
			l.image=self.backbutton
			l.place(x=20,y=20)
			l.bind('<Button-1>',lambda event:Application().HomeScreen())
		
			#name
			dp=Label(c,image=self.default_boy,bg='white')
			dp.image=self.default_boy
			dp.place(x=70,y=150)
			
			Label(c,text=name,fg='sea green',bg='white',font='verdana '+readtool.autoxy(name)+' bold').place(x=40,y=300)		
			global chatvar
			chatvar=StringVar()
			#cc=Frame(c,width=int(self.height)+2,height=150,bg='white').place(x=-1,y=600)
			
			self.autoInsertChats(list_box)

			#           C H A T      S E CT I O N             #
			chat_section=Entry(c,textvariable=chatvar,bg='blue',fg='white',font='verdana 11',relief=RAISED)
			chat_section.place(x=250,y=453,width=320,height=30)

			#------------------- enter button bind   ---------------------
			root.bind('<Return>',lambda e:self.sendButton()
                                  )
			
			Button(c,text='send',command=self.sendButton,padx=33,pady=3).place(x=570,y=453)
			
			fullscreenToogle=Label(c,text='FullScreen View',font='verdana 17 bold',bg='white')
			#fullscreenToogle.place(x=100,y=900)
			
			fullscreenToogle.bind('<Button-1>',lambda event:self.chatscreenDESKTOP(name))
			root.update()
			#chat_section.bind('<Button-1>',lambda event:self.addRecievedChat(list_box))
			#list_box.bind('<Button-1>',lambda event:self.addRecievedChat(list_box))
			process=Process(target=self.addRecievedChat(list_box))
			process.start()
			
	
	def autoInsertChats(self,whichListBox):
		whichListBox.delete(0,END)
		with open(win('database/chats/current_data'),'r') as f:
			d=f.readlines()
			d=d[0]
		with open(win('database/chats/db/')+d,'r') as f:
			dd=f.readlines()
			dd=dd[0]	
		dd=dd.split('+-=-')
		dd.pop(0)
		for i in dd:
			whichListBox.insert(END,i)
			
			
	def addRecievedChat(self,whichListBox):
		with open(win('database/chats/current_data'),'r') as f:
			d=f.readlines()
			d=d[0]
		c=funcforgui.addNewChatMessage(d)
		if c != None:
			whichListBox.insert(END,c)
		
				
	def sendButton(self): #chat updation
		global chatvar,list_box,indexing
		list_box.insert(END,'[ME] '+chatvar.get())
		
		with open(win('database/chats/current_data'),'r') as f:
			d=f.readlines()
			d=d[0]
		with open(win('database/chats/db/'+d),'a') as f:
			f.write('+-=-[ME] '+chatvar.get())
                #terminal.send(chatvar.get())
		chatvar.set('')
		def a1(self):
			pass
		indexing+=1
		list_box.see(indexing)
		
class Application(allDATA):
	def __init__(self):
		super(Application,self).__init__(root)
	
	def editmenu(self):
		self.HomeScreen()
		
		
		
	def HomeScreen(self):
		frame=Frame(self.root,height=self.height,width=self.width,bg='white').place(x=0,y=0)
		#Label(frame,padx=355,pady=40,bg='dodger blue',relief=SUNKEN,text=' ').place(x=0,y=0)
		

		#Label(frame,text='Steller X ',bg='dodger blue',fg='white',font='verdana 13 bold').place(x=20,y=20)

		'''
		threeDOT=Label(frame,text='≡',bg='dodger blue',fg='white',font='verdana 20 bold')
		threeDOT.place(x=600,y=14,width=100,height=80)
		threeDOT.bind('<Button-1>',lambda event: self.profile(event))
		'''
		
		add_chat=Label(frame,image=self.plus,bg='dodger blue',fg='white',font='verdana 20 bold')
		add_chat.image=self.plus
		add_chat.place(x=10,y=452,width=32,height=32)
		add_chat.bind('<Button-1>',self.addChatButtonFunc)
		
		'''
		refreshScreen=Label(frame,image=self.refresh_button,bg='dodger blue',fg='white',font='verdana 20 bold')
		refreshScreenimage=self.refresh_button
		refreshScreen.place(x=400,y=14,width=100,height=80)
		refreshScreen.bind('<Button-1>',lambda event:self.editmenu())
		'''
		
		search=StringVar()
		search_bar=Entry(frame,textvariable=search,bg='black',fg='white',font='verdana 11')
		search_bar.place(x=10,y=10,height=40,width=200)
		search.set(' 🔍| Search')
		search_bar.bind('<Button-1>',lambda event:search.set(''))
		
		bglabel=Label(frame,image=self.bg)
		bglabel.image=self.bg
		bglabel.place(x=210,y=8)
		
		
		
		with open(win('database/chats/data/homeID'),'r') as f:
			DATA=f.readlines()
			DATA=DATA[0]
		newDATA=[]
		for i in DATA.split('+-=-'):
			newDATA.append(i)
		newDATA.pop(0)
		chat_DATA={}
		for i in newDATA:
		  i=i.split(',')
		  chat_DATA[i[1]]=i[2]
		  
		scrollbar=Scrollbar(root)
		scrollbar.place(x=680,y=205,height=950)
		listbox=Listbox(frame,font='verdana 11',bg='black',fg='chartreuse2',yscrollcommand=scrollbar.set)
		for i in chat_DATA.keys():
			listbox.insert(END,'  '+str(i))
			listbox.insert(END,'')
		listbox.place(x=10,y=55,height=390,width=200)
		scrollbar.config(command=listbox.yview)
		listbox.bind('<<ListboxSelect>>', lambda e: self.chatOnClick(listbox.get(listbox.curselection())))

		HOME_BUTTON=Button(frame,image=self.homeButton,bg='white')
		STATUS_BUTTON=Button(frame,image=self.statusButton,bg='white')
		HOME_BUTTON.image=self.homeButton
		STATUS_BUTTON.image=self.statusButton
		HOME_BUTTON.place(x=0,y=1165,width=360)
		STATUS_BUTTON.place(x=360,y=1165,width=360)


		Button(frame,text='LogOut',command=self.logout,pady=6,padx=20).place(x=581,y=450)
		Button(frame,text='My Account',bg='dodger blue',fg='white',command=self.profile,pady=6,padx=20).place(x=49,y=450)

	def chatOnClick(self,NAME):
		if os.path.isfile(win('database/chats/db/'+NAME))==False:
			with open(win('database/chats/db/'+NAME),'a') as f:
				f.write('+-=-')
				f.close()
		with open(win('database/chats/current_data'),'w') as f:
			f.write(NAME)
		root.update_idletasks()
		time.sleep(0.0001)
		ChatUi().ChatScreen(NAME)
		
	
		
	def chatIconPlacer(self,whichFRAME,NAME,SUBTITLE,img,BG,XY):
		AVATARlabel=Label(whichFRAME, image=img,bg='white')
		AVATARlabel.image=img
		AVATARlabel.place(x=20,y=XY[1])
		
		L=Label(whichFRAME,text=NAME,font='verdana 8 bold',bg=BG)
		L.place(x=XY[0],y=XY[1])
		Label(whichFRAME,text=SUBTITLE,font='verdana 6',bg=BG).place(x=XY[0],y=XY[1]+50)
		L.bind('<Button-1>',lambda event:self.chatOnClick(NAME))
	
		
		
	def addChatButtonFunc(self,event):
		add=Toplevel()
		add.config(bg='white')
		add.title('Add Chat')
		add.geometry('500x250+90+320')
		global user_Name,uid
		user_Name=StringVar()
		uid=StringVar()
		#Entry(add,textvariable=user_Name).place(x=60,y=20)
		Label(add,text='USERNAME',font='verdana 8 bold',bg='white').place(x=60,y=12)
		Entry(add,textvariable=user_Name).place(x=60,y=70)
		Button(add,text='add',bg='dodger blue',pady=5,padx=100,command=self.getUserNameAndUID).place(x=130,y=150)
		
	def getUserNameAndUID(self):
		global user_Name
		with open(win('database/chats/data/homeID'),'a') as f:
			rawDATA=getUserInfoForNewChat(user_Name.get())
			if rawDATA != None:
				f.write('+-=-'+user_Name.get()+','+str(rawDATA[0])+','+str(rawDATA[1]))
				with open(win('database/chats/db/'+str(rawDATA[0])),'w') as f:
					f.write('[Stellerx] Say hi to '+rawDATA[0])
				msgbox.showinfo('Notification','now You can chat with\n'+rawDATA[0]+' ('+user_Name.get()+')')
				root.update()
			else:
				msgbox.showwarning('Alert','you have entered a wrong\nusername ..')
		
	def profile(self):#,event
		global data
		#data=['rajatdivyansheye',1,'RAJAT JAISAWAL','17','male','durgeshrawat.info@gmil.com',51]
		proframe=Frame(self.root,height=self.height,width=self.width,bg='white').place(x=0,y=0)
		
		#refrence
		#label=Label(proframe, image=self.PROFILE,bg='white')
		#label.image=self.PROFILE
		#label.place(x=-1,y=-30)
		
		AVATARlabel=Label(proframe, image=self.default_avatar,bg='white')
		AVATARlabel.image=self.default_avatar
		AVATARlabel.place(x=50,y=115)
	
		#line=Label(proframe,text='_'*30,bg='white').place(x=20,y=290)
			
		backbutton1=Label(proframe,image=self.backbutton,bg='white')
		backbutton1.image=self.backbutton
		backbutton1.place(x=50,y=50)
		backbutton1.bind("<Button-1>",lambda event : self.HomeScreen())
		Label(proframe,text='Profile & Settings',font='verdana 10 bold',bg='white').place(x=130,y=50)
		#0 username 1 password 2 fullname 3 age 4 gender 5 gmail
		
		full_name=Label(proframe,text=data[2],font='verdana 12 bold',bg='white').place(x=180,y=130)
		user_name=Label(proframe,text=data[0],font='verdana 8',bg='white').place(x=180,y=170)
		Label(proframe,text=f'your uid : {str(data[6])}',font='verdana 8',bg='white').place(x=150,y=675)
		account_details=Label(proframe,text='Account Details',font='verdana 12',bg='white')
		account_details.place(x=80,y=250)
		
		
		chat_settings=Label(proframe,text='Chat Settings',font='verdana 12',bg='white')
		chat_settings.place(x=80,y=300)

		
		logout_Button=Button(proframe,text='Logout',bg='alice blue',command=self.logout).place(x=80,y=350)
	def logout(self):
		Main().Home()
		with open(win('database/logs.txt'),'w') as f:
			fi=f.write('False,None,None')
if __name__=='__main__': # here i used this statement for show that( ager ye programm directley isi programm se run ho rhau hai to hinchale warna naa chale (justlike ager koi mere is module ko import kre to ye jo if ke indent me likha hai wo na run ho) )
	root=Tk()
	allDATA(root)
	#"""
	INTRO()
	root.update_idletasks()
	time.sleep(3)
	Main()
	#"""
	#Application().profile()
	#MainFunctions().CreateAccount(0)
	#MainFunctions().CreateAccountSTEP2()
	#Application().HomeScreen()
	#ChatUi().ChatScreen('stellerx')
	#"""
	root.mainloop()
