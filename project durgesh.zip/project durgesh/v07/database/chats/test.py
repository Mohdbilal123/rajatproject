import os,time
while True:
    time.sleep(1)
    os.system('cat current_data')
    print('')
