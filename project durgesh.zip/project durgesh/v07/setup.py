#setup.py
import os
for i in ['requests','beautifulsoup4','pillow','python-wordpress-xmlrpc']:
	os.system(f'pip install {i}')
print('setup complete')