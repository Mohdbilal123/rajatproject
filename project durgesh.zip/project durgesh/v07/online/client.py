from cloudhost import Core
class Terminal:
    def __init__(self):
        self.console=Core.Console('https://stellerxserver.wordpress.com',
                     'stellerx',
                     'stellerx.incorrect')
    def send(self,username,message):
        self.console.Update(username,message)
        return True
    
    def recieve(self,username):
        return self.console.ShowNewData(username)

    def clear_chat(self,username):
        return True

if __name__=='__main__':
    print('''
    1 - send
    2 - recieve''')
    while True:
        if input('choose - ')=='1':
            Terminal().send('f111',input('write message : '))
        else:
            print(Terminal().recieve('f111'))
