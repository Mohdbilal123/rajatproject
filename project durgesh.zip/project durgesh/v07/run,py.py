#run button
import os
from tkinter import *
def run():
    os.system('python main.py')
root=Tk()
Button(root,text='run',bg='black',fg='white',padx=50,pady=40,command=run).pack()
root.mainloop()
