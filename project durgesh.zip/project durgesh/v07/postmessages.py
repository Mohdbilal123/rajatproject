import requests
from bs4 import BeautifulSoup

from wordpress_xmlrpc import Client
from wordpress_xmlrpc.methods import posts
from wordpress_xmlrpc import WordPressPost

class de:
    def encrypt(value):
        real=[' '];encrypt=[' ']
        for r in range(33,132):
            real.append(chr(r))
        for e in range(131,32,-1):
            encrypt.append(chr(e))
        encrypted_form=''
        for string in value:
            encrypted_form+=encrypt[real.index(string)]
        return encrypted_form
    def decrypt(value):
        real=[' '];decrypt=[' ']
        for r in range(33,132):
            real.append(chr(r))
        for e in range(131,32,-1):
            decrypt.append(chr(e))
        decrypted_form=''
        for string in value:
            decrypted_form+=decrypt[real.index(string)]
        return decrypted_form
        
        
def makePost(Title,message):	
	your_blog = Client('https://stellerxserver.wordpress.com/xmlrpc.php', 'durgeshrawat0000.info@gmail.com', 'stellerx.incorrect')
	myposts=your_blog.call(posts.GetPosts())
	post = WordPressPost()
	post.title = Title
	post.slug='0'
	post.content = message
	post.post_status = 'publish'
	post.id = your_blog.call(posts.NewPost(post))
	print(post.id)
	return post.id
	
def editPost(postID,link_of_post,Title,newMessage):
	your_blog = Client('https://stellerxserver.wordpress.com/xmlrpc.php', 'durgeshrawat0000.info@gmail.com', 'stellerx.incorrect')
	post = WordPressPost()
	post.slug='0'
	post.content =str(getPost(link_of_post))+'<new>'+str(newMessage)
	your_blog.call(posts.EditPost(postID, post))
	return True

def getPost(link):
	page = requests.get(link)
	soup = BeautifulSoup(page.content, 'html.parser')
	page_title = soup.title
	a=soup.find_all('p')
	return a[1].get_text()
	
def AuthenticationUserData():
	id = 'durgeshrawat0000.info@gmail.com'
	password = 'stellerx.incorrect'
	client = Client('https://stellerxserver.wordpress.com/xmlrpc.php', id, password)
	wp_posts=client.call(posts.GetPosts())
	return wp_posts[1].content


#@authentication
#print(de.decrypt(getPost('https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/')))#AuthenticationUserData()))


"""	
editPost(30,'https://stellerxserver.wordpress.com/2021/07/15/my_post_permanent_link-2/','welcome to steller x server - ngdox')
print(getPost('https://stellerxserver.wordpress.com/2021/07/15/my_post_permanent_link-2/'))
"""

# >> post edit (for new content)
# >>> authentication symbol b/w username & password

#makePost(de.encrypt('authentication'),de.encrypt('durgeshrawat>>>incorrect'))
#44 id for authentication

"""
print(getPost('https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/'))
editPost(70,'https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/',de.encrypt('authentication'),de.encrypt('durgesh0>>>12345<n>'))
#makePost(de.encrypt('authentication'),de.encrypt('hello<n>'))
print(getPost('https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/'))
"""
def updateUserInfo(list_of_userdata):
	data=''
	for i in list_of_userdata:
		data+=i+'+-=-'
	data=de.encrypt(data)
	data+=de.encrypt('<n>')
	if editPost(70,'https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/',de.encrypt('authentication'),data) == True:
		return True
		
	
def getUserInfo(username,password):
	a=getPost('https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/')
	#a=AuthenticationUserData()
	a=de.decrypt(a)
	a=a.split('[new]')
	for i in a:
		j=i.split('+-=-')
		if j[0]==username:
			if j[1]==password:
				return j
				
#getUserInfo()
#updateUserInfo(['a','a','a','a','a'])
#editPost(70,'https://stellerxserver.wordpress.com/2021/07/15/c-060ac056-2/',de.encrypt('authentication'),de.encrypt('durgesh.rwt+-=-durgsh@123+-=-DURGESH RAWAT+-=-17+-=-male+-=-durgesh@gmail.com<n>'))
#print(getUserInfo('a','a'))


#========== c h a t  s e r v e r ================
#id=109
#makePost('chatserver','welcome in steller x server')#109 id
def getChat(link):
	a=getPost(link)
	print(a)
	
i=0
def postChat(id,link,title,message):
	your_blog = Client('https://stellerxserver.wordpress.com/xmlrpc.php', 'durgeshrawat0000.info@gmail.com', 'stellerx.incorrect')
	post = WordPressPost()
	post.slug='0'
	global i 
	if i < 5:
		post.content =str(getPost(link))+'<new>'+str(message)
		i+=1
	else:
		post.content =str(message)
		i=0
	your_blog.call(posts.EditPost(id, post))
	return True
