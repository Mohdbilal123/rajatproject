#all addressses
def win(address):
    with open('device_info','r') as f:
    	di=f.readlines()
    	di=di[0]
    toreturn=''
    for i in address:
        if i=='/':
            if di == 'android=True':
            	toreturn+='/'
            else:
            	toreturn+='\\'
        else:
            toreturn+=i

    return toreturn

if __name__=='__main__':
    print(win('sdcard/storage/fg/dfg/dd//dgdfgdg/'))
