import wordpress_api,time
from wordpress_api import wordpress_posts,de,chat
#getpostINFO,updateUserInfo

def getUserInfo(username,password):
	username=username
	a=wordpress_posts().getAuthenticationInfo()
	a=de.decrypt(a)
	a=a.split('?Ubt!')
	for i in a:
		j=i.split('+-=-')
		if j[0]==username:
			if j[1]==password:
				return j
					
def updateUserInfo(list_of_userdata):
	data=''
	for i in list_of_userdata:
		data+=i+'+-=-'
	data=de.encrypt(data)
	data+=de.encrypt(str(chat().makeNewChat(de.encrypt(list_of_userdata[0]+'.server'),de.encrypt('hey there i am using stellerx'))))
	data+=de.encrypt('+-=-')
	data+=de.encrypt('[new]')
	if wordpress_posts().editPost(129,data) == True: #129 authentication post id
		return True

		
				
def getUserInfoForNewChat(uname):
	username=uname
	a=wordpress_posts().getAuthenticationInfo()
	a=de.decrypt(a)
	a=a.split('?Ubt!')
	for i in a:
		j=i.split('+-=-')
		if j[0]==username:
			return j[2],j[6]

def addNewChatMessage(username):
	a=chat().recieveNewChat(username)
	"""
	while True:
		time.sleep(0.10)
		b=chat().recieveNewChat(username)
		if b!=a:
			a=b
			return b
	"""
				
	b=chat().recieveNewChat(username)
	if b!=a:
		a=b
		return b	
				
