# 129  is the testing id of post
import requests
from bs4 import BeautifulSoup
from wordpress_xmlrpc import Client
from wordpress_xmlrpc.methods import posts
from wordpress_xmlrpc import WordPressPost

class ddee:
    def encrypt(value):
        real=[' '];encrypt=[' ']
        for r in range(33,132):
            real.append(chr(r))
        for e in range(131,32,-1):
            encrypt.append(chr(e))
        encrypted_form=''
        for string in value:
            encrypted_form+=encrypt[real.index(string)]
        return encrypted_form
    def decrypt(value):
        real=[' '];decrypt=[' ']
        for r in range(33,132):
            real.append(chr(r))
        for e in range(131,32,-1):
            decrypt.append(chr(e))
        decrypted_form=''
        for string in value:
            decrypted_form+=decrypt[real.index(string)]
        return decrypted_form
class de:
	def encrypt(data):
		a=list(" aABCDEFGHIJKbcdefghijklLMNOPQRSTUVmnopqrsWXYZtuvwxyz1234567890;.,*+-/=!'@$():?!#[]{}<>&_%√|\~•`€¥£¢¤π™©®^βαα")
		b=''
		for i in data:
			b+=a[a.index(i)+3]
		return b
	def decrypt(data):
		a=list(" aABCDEFGHIJKbcdefghijklLMNOPQRSTUVmnopqrsWXYZtuvwxyz1234567890;.,*+-/=!'@$():?!#[]{}<>&_%√|\~•`€¥£¢¤π™©®^βαα")
		b=''
		for i in data:
			if a.index(i)==0:
				b+=a[0]
			else:
				b+=a[a.index(i)-3]
		return b
class wordpress_posts:
    def __init__(self):
        with open('database/core/auth','r') as f:
        	auth=f.readlines()
        	auth=auth[0]
        	auth=auth.split('+-=-')
        self.username=ddee.decrypt(auth[0])
        self.password=ddee.decrypt(auth[1])
        self.url=ddee.decrypt(auth[2])
        
    def makePost(Title,message):	
    	your_blog = Client(self.url, self.username, self.password)
	    #myposts=your_blog.call(posts.GetPosts())
    	post = WordPressPost()
    	post.title = Title
    	post.slug='0'
    	post.content = message
    	post.post_status = 'publish'
    	post.id = your_blog.call(posts.NewPost(post))
    	print(post.id)
    	return post.id
	
    def editPost(self,postID,newMessage):
	    your_blog = Client(self.url,self.username,self.password)
	    post = WordPressPost()
	    post.slug='0'
	    #post.content=newMessage
	    post.content =str(self.getpostsINFO(2))+'[new]'+str(newMessage) # for authentication info
	    your_blog.call(posts.EditPost(postID, post))
	    return True

    def getPost(link): #get post by BeautifulSoup4
	    page = requests.get(link)
	    soup = BeautifulSoup(page.content, 'html.parser')
	    page_title = soup.title
	    a=soup.find_all('p')
	    return a[1].get_text()

    def getpostsINFO(self,indexOfPost): #get posts by xmlrpc.php server
	    client = Client(self.url, self.username, self.password)
	    wp_posts = client.call(posts.GetPosts())
	    #for i in wp_posts:
	    #    print(i,wp_posts.index(i))
	    return wp_posts[indexOfPost].content
	    
    def getAuthenticationInfo(self):
        client = Client(self.url, self.username, self.password)
        wp_posts = client.call(posts.GetPosts())
        post_no=0
        if len(wp_posts)==3:
        	post_no=0
        else:
        	if len(wp_posts) > 3:
        		post_no=len(wp_posts)-3
        return wordpress_posts().getpostsINFO(2)
#wordpress_posts.makePost('emails',de.encrypt('asdf@gmail.com')) #post id = 129
#print(wordpress_posts.getPost('https://stellerxserver.wordpress.com/2021/07/18/testing1/'))

"""
while True:
    print('\033[0;32;40m|                chat server)                |\033[0;37;40m')
    print('\t[1]  send message')
    print('\t[2]  view message')
    
    if input(' > ')=='1':
        wordpress_posts().editPost(129,de.encrypt(input('message > ')))
    else:    
        print(de.decrypt(wordpress_posts().getAuthenticationInfo()))
 
"""       
#print(de.decrypt(wordpress_posts().getAuthenticationInfo()))
#print(wordpress_posts().getpostsINFO(0))
#wordpress_posts().editPost(129,de.encrypt('admin 123'))

class chat:
	def __init__(self):
		with open('database/core/chatserver','r') as f:auth=f.readlines()
		auth=auth[0];auth=auth.split('+-=-');self.username=ddee.decrypt(auth[0]);self.password=ddee.decrypt(auth[1]);self.url=ddee.decrypt(auth[2])
        
	
	def makeNewChat(self,Title,message):
	    your_blog = Client(self.url,self.username,self.password)
	    #myposts=your_blog.call(posts.GetPosts())
	    post = WordPressPost()
	    post.title = Title
	    post.slug='0'
	    post.content = message
	    post.post_status = 'publish'
	    post.id = your_blog.call(posts.NewPost(post))
	    print(post.id)
	    return post.id #chat id
    
	def postIndex(self):
	    client = Client(self.url, self.username, self.password)
	    wp_posts = client.call(posts.GetPosts())
	    indexes={}
	    for i in wp_posts:
	    	#print(i,wp_posts.index(i))
	    	indexes[i.title]=wp_posts.index(i)
	    return indexes
	    
	    
	def getIndex(self,username):
	    username=de.encrypt(username)+de.encrypt('.server')
	    d=self.postIndex()
	    return d[username]
	    
	   
	    
	def recieveFullChat(self,username):
	    client = Client(self.url, self.username, self.password)
	    wp_posts = client.call(posts.GetPosts())
	    return de.decrypt(wp_posts[self.getIndex(username)].content)

	def recieveNewChat(self,username):
		chat=self.recieveFullChat(username)
		chat=chat.split('[new}iX8['+username+'}iX8')
		return chat[len(chat)-1]
		
	def send(self,chat_id,message,username):
		client = Client(self.url, self.username, self.password)
		wp_posts = client.call(posts.GetPosts())
		index=self.getIndex(username)
		chat=wp_posts[index].content
		chatTitle=wp_posts[index].title
		newChat=chat+de.encrypt('[new]'+'['+username+'] '+message)
		post = WordPressPost()
		post.slug='0'
		post.title=chatTitle
		post.content=newChat
		client.call(posts.EditPost(chat_id, post))
		return True
		
	def clearChat(self,chat_id,username): #de.encrypt(username.server)
		client = Client(self.url, self.username, self.password)
		wp_posts = client.call(posts.GetPosts())
		chatTitle=wp_posts[self.getIndex(username)].title
		newChat=' '
		post = WordPressPost()
		post.slug='0'
		post.title=chatTitle
		post.content=newChat
		client.call(posts.EditPost(chat_id, post))
		return True

		
		



if __name__=='__main__':
    import time
    c=chat()

    print('''
	[1] send
	[2] recieve
	[3] clear chat
	[4] newchat recieve''')

    ID=29
    USER='bob'


    while True:
        ch=input(' > ')
        if ch == '2':
            print(c.recieveFullChat(USER))
        elif ch == '1':
            print(c.send(ID,input('> '),USER))
        elif ch == '3':
            print(c.clearChat(ID,USER))
        elif ch =='4':
            print(c.recieveNewChat(USER))
        else:break
    



# chat