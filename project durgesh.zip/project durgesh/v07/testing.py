import os
print(os.path.isdir('database/assets/bglogo.jpg'))